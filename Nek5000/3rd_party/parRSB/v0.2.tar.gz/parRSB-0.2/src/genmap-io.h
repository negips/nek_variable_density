#ifndef _GENMAP_READERS_H_
#define _GENMAP_READERS_H_

int GenmapCreateHandle_interface(GenmapHandle h);
int GenmapRead_interface(GenmapHandle h, void *data);

#endif
